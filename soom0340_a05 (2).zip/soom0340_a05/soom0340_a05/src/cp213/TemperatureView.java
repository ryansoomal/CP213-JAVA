package cp213;

import java.awt.Color;
import java.awt.Graphics;

/**
 * Horizontal bar view of current reactor temperature.
 *
 * @author Ryan Soomal 210370340
 * @version 2021-11-25
 */
@SuppressWarnings("serial")
public class TemperatureView extends BarView {

    private Reactor model = null;
    /**
     * constructor
     * @param model The reactor
     */
    public TemperatureView(Reactor model) {
    	super(Color.GREEN,Reactor.MAX_TEMP);
    	this.model = model;
    }
    
    @Override
    public void paintComponent(Graphics g) {
    		this.modelValue = this.model.getTemperature();
    		super.paintComponent(g);
    }

}