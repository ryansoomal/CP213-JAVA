package cp213;

public class Test {
	
	
	public static void main(String[] Args) {
		/*
		BST bst1 = new BST();
		BST bst2 = new BST();
		//System.out.println(bst1.equals(bst2));
		CountedCharacter c = new CountedCharacter('C');
		CountedCharacter d = new CountedCharacter('D');
		CountedCharacter e = new CountedCharacter('E');
		CountedCharacter a = new CountedCharacter('A');
		CountedCharacter f = new CountedCharacter('F');
		bst1.insert(c);
		bst1.insert(d);
		bst1.insert(d);
		
		bst1.insert(e);
		bst1.insert(a);
		System.out.println(bst1.root.toString());
		*/
		
		PopularityTree p = new PopularityTree();
		//11,7,15,6,9,12,18,8
		CountedCharacter a = new CountedCharacter('a');
		CountedCharacter b= new CountedCharacter('b');
		CountedCharacter c = new CountedCharacter('c');
		p.insert(a);
		p.insert(b);
		p.insert(c);
		System.out.println(p.root.toString());
		p.retrieve(b);
		System.out.println(p.root.toString());
		
	}
}
