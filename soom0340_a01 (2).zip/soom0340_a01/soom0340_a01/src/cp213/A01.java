package cp213;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 * 
 * @author Ryan Soomal 210370340
 * @version 1.0
 */
public class A01 {

	/**
	 * Main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// take user input
		//Scanner in = new Scanner(System.in);
		// code for palindrome method
		/*
		 * System.out.print("Enter a string: "); String s = in.nextLine(); boolean isPal
		 * = isPalindrome(s); //print result of palindrome test if (isPal) {
		 * System.out.println("'" + s + "'" + " is a palindrome."); } else {
		 * System.out.println("'" + s + "'" + " is not a palindrome."); }
		 */

		// code for variable validation
		/*
		 * System.out.print("Enter a string: "); String s = in.nextLine(); boolean valid
		 * = isValid(s); if (valid) {
		 * System.out.println("'"+s+"'"+" is a valid Java name."); } else {
		 * System.out.println("'"+s+"'"+" is not a valid Java name."); }
		 */

		// code for pig latin
		/*
		 System.out.print("Word: "); String s = in.nextLine(); String latin =
		 pigLatin(s); System.out.println("Pig-Latin: "+latin);
		 */
		
		//code for leap year
		/*
		System.out.print("Enter year: ");
		int year = in.nextInt();
		boolean isLeap = isLeapYear(year);
		if (isLeap) {
			System.out.println(year+" is a leap year.");
		}
		else {
			System.out.println(year+" is not a leap year.");
		}
		*/
		
		//code for matrix stats
		/*
		double[][] arr = { { 1, 2 }, { 3, 4 } }; 
		double[] a = matrixStats(arr);
		System.out.println("Smallest: "+a[0]);
		System.out.println("Largest: "+a[1]);
		System.out.println("Total: "+a[2]);
		System.out.println("Average: "+a[3]);
		*/
	}

	/**
	 * Determines if s is a palindrome. Ignores case, spaces, digits, and
	 * punctuation in the string parameter s.
	 *
	 * @param s a string
	 * @return true if s is a palindrome, false otherwise
	 */
	public static boolean isPalindrome(final String s) {
		boolean isPal = true;
		int len = s.length();
		ArrayList<Character> chars = new ArrayList<>();
		// loop through the string, removing non alphabet characters
		for (int i = 0; i < len; i++) {
			Character check = s.charAt(i);
			if (Character.isLetter(check)) {
				chars.add(Character.toLowerCase(check));
			}
		}
		// make a second arraylist and add the first arraylist into it in reverse
		int aSize = chars.size() - 1;
		ArrayList<Character> reversed = new ArrayList<>();
		while (aSize >= 0) {
			reversed.add(chars.get(aSize));
			aSize--;
		}
		// compare the two arraylists
		if (!chars.equals(reversed)) {
			isPal = false;
		}
		return isPal;
	}

	/**
	 * Determines if name is a valid Java variable name. Variables names must start
	 * with a letter or an underscore, but cannot be an underscore alone. The rest
	 * of the variable name may consist of letters, numbers and underscores.
	 *
	 * @param name a string to test as a Java variable name
	 * @return true if name is a valid Java variable name, false otherwise
	 */
	public static boolean isValid(final String name) {
		boolean valid = true;
		if (name.length() > 0) {
			// check first character
			Character first = name.charAt(0);
			String underscore = "_";
			if (!Character.isLetter(first)) {
				// if underscore check length
				if (name.equals(underscore)) {
					valid = false;
				} else if (Character.isDigit(first)) {
					valid = false;
				}
			}
			// loop through to make sure there's no special characters
			char b = '_';
			Character u = new Character(b);
			int i = 0;
			int nameLength = name.length();
			while (valid && i < nameLength) {
				Character temp = name.charAt(i);
				if ((!Character.isDigit(temp)) && (!Character.isLetter(temp)) && (!temp.equals(u))) {
					valid = false;
				}

				i++;
			}

		} else {
			valid = false;
		}

		return valid;
	}

	/**
	 * Converts a word to Pig Latin. The conversion is: if a word begins with a
	 * vowel, add "way" to the end of the word. if the word begins with consonants,
	 * move the leading consonants to the end of the word and add "ay" to the end of
	 * that. "y" is treated as a consonant if it is the first character in the word,
	 * and as a vowel for anywhere else in the word.
	 *
	 * Preserve the case of the word - i.e. if the first character of word is
	 * upper-case, then the new first character should also be upper case.
	 *
	 * @param word The string to convert to Pig Latin
	 * @return the Pig Latin version of word
	 */
	public static String pigLatin(String word) {
		// convert the string to an array of chars
		char[] chars = word.toCharArray();
		char[] vowels = { 'a', 'e', 'i', 'o', 'u' };
		char first = chars[0];
		String latin = "";
		// see if the first character is a vowel by doing a linear search of the vowels
		// array
		boolean vowel = false;
		int i = 0;
		while (!vowel && i < 5) {
			if (first == vowels[i]) {
				vowel = true;
			}
			i++;
		}
		// if it's a vowel add "way" to the end of the word
		if (vowel) {
			latin = word + "way";
		}
		// move the consonants until you get a vowel
		else {
			char[] vowelsAndY = { 'a', 'e', 'i', 'o', 'u', 'y' };
			// find the first vowel
			int len = word.length();
			int x = 0;
			boolean found = false;
			// loop through each character and check each character
			// stop when a vowel is found
			while (!found && x < len) {
				char temp = chars[x];
				int y = 0;
				boolean isVowel = false;
				while (!isVowel && y < 6) {
					if (temp == vowelsAndY[y]) {
						isVowel = true;
						found = true;
					}
					y++;
				}
				x++;
			}
			//check if no vowels were found
			if (x==len) {
				latin = word+ "ay";
			}
			else {
				x -= 1;
			// check if first character was upper case
			boolean upper = false;
			Character f = new Character(first);
			if (Character.isUpperCase(f)) {
				upper = true;
			}
			// move chars
			// make two arrays one for each half of the word
			int mover = 0;
			char[] beginning = new char[x];
			char[] rest = new char[word.length() - x];
			while (mover < x) {
				beginning[mover] = chars[mover];
				mover++;
			}
			int mover2 = 0;
			while (mover < word.length()) {
				rest[mover2] = chars[mover];
				mover++;
				mover2++;
			}
			// conserve case if need be
			if (upper) {
				beginning[0] = Character.toLowerCase(f);
				rest[0] = Character.toUpperCase(rest[0]);
			}
			// combine the two arrays and add the ending

			latin = String.valueOf(rest) + String.valueOf(beginning) + "ay";
			}
			

		}

		return latin;
	}

	/**
	 * Determines whether or not a year is a leap year.
	 *
	 * @param year The year to test (int > 0)
	 * @return true if year is a leap year, false otherwise.
	 */
	public static boolean isLeapYear(final int year) {
		boolean leap = true;
		//do the math
		if (year % 4 == 0) {
			if (year % 100 == 0) {
				if (year % 400 != 0) {
					leap = false;
				}

			}
		} else {
			leap = false;
		}

		return leap;
	}
	
	
    /**
     * Determines the smallest, largest, total, and average of the values in the 2D
     * list a. You may assume there is at least one value in a and that a is a
     * square matrix - i.e. the number of columns per row is the same. a must be
     * unchanged.
     *
     * @param a - a 2D list of numbers (2D list of double)
     *
     * @return a list of four double values containing the smallest number in a,the
     *         largest number in a, the total of all numbers in a, and the average
     *         of all numbers in a, in that order.
     */
    public static double[] matrixStats(double[][] a) {
    	//initialize vars
    	double smallest = a[0][0];
        double largest = a[0][0];
        double total = 0;
        double average = 0;
        int count = 0;
        double[] nums = new double[4];
        //loop through the matrix
        for(int i=0;i<a.length;i++) {
        	for(int j=0;j<a[0].length;j++) {
        		//update smallest and largest
        		if(a[i][j]<smallest) {
        			smallest = a[i][j];
        		}
        		if(a[i][j]>largest) {
        			largest = a[i][j];
        		}
        		//update total and count
        		total+=a[i][j];
        		count++;
        	}
        }
        average = total/count;
        
        nums[0] = smallest;
        nums[1] = largest;
        nums[2] = total;
        nums[3] = average;
        return nums;
    }
}
