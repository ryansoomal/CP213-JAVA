package cp213;

/**
 * A simple linked list structure of <code>Node T</code> objects. Only the
 * <code>T</code> data contained in the stack is visible through the standard
 * list methods. Extends the <code>SingleLink</code> class, which already
 * defines the head node, length, iterator, and toArray.
 *
 * @author David Brown
 * @version 2021-10-16
 * @param <T> this SingleList data type.
 */
public class SingleList<T extends Comparable<T>> extends SingleLink<T> {

	/**
	 * Searches for the first occurrence of key in this SingleList. Private helper
	 * methods - used only by other ADT methods.
	 *
	 * @param key The value to look for.
	 * @return A pointer to the node previous to the node containing key.
	 */
	private SingleNode<T> linearSearch(final T key) {
		SingleNode<T> prev = null;
		SingleNode<T> curr = this.head;
		boolean found = false;

		while (!found && curr != null) {
			if (curr.getValue().compareTo(key) == 0) {
				found = true;
			} else {
				prev = curr;
				curr = curr.getNext();

			}
		}

		if (!found) {
			prev = null;
		}

		return prev;
	}

	/**
	 * A helper method to move the front node of the SingleList source to this
	 * SingleList.
	 *
	 * @param source The list to move the front of.
	 */
	private void moveFront(final SingleList<T> source) {
		SingleNode<T> node = source.head;
		// update source list
		source.length--;
		source.head = source.head.getNext();
		// update the target list
		if (this.isEmpty()) {
			this.head = node;
		} else {
			SingleNode<T> curr = this.head;
			while (curr.getNext() != null) {
				curr = curr.getNext();
			}
			curr.setNext(node);

		}
		node.setNext(null);
		this.length++;
		return;

	}

	/**
	 * Appends data to the end of this SingleList.
	 *
	 * @param data The data to append.
	 */
	public void append(final T data) {

		SingleNode<T> node = new SingleNode<T>(data, null);

		if (this.isEmpty()) {
			this.head = node;
		} else {
			SingleNode<T> curr = this.head;
			while (curr.getNext() != null) {
				curr = curr.getNext();
			}
			curr.setNext(node);
		}
		this.length++;

	}

	/**
	 * Removes duplicates from this SingleList. The list contains one and only one
	 * of each value formerly present in this SingleList. The first occurrence of
	 * each value is preserved.
	 */
	public void clean() {

		SingleNode<T> ptr1 = this.head;
		SingleNode<T> ptr2 = null;
		SingleNode<T> dup = null;
		// pick elements one by one
		while (ptr1 != null && ptr1.getNext() != null) {
			ptr2 = ptr1;

			// compare the picked element with the rest of the list
			while (ptr2.getNext() != null) {
				// if duplicate then delete it
				if (ptr1.getValue().compareTo(ptr2.getNext().getValue()) == 0) {
					dup = ptr2.getNext();
					ptr2.setNext(ptr2.getNext().getNext());
					this.length--;
				} else {
					ptr2 = ptr2.getNext();
				}
			}
			ptr1 = ptr1.getNext();
		}

	}

	/**
	 * Combines contents of two lists into a third. Values are alternated from the
	 * origin lists into this SingleList. The origin lists are empty when finished.
	 * NOTE: data must not be moved, only nodes.
	 *
	 * @param left  The first list to combine with this SingleList.
	 * @param right The second list to combine with this SingleList.
	 */
	public void combine(final SingleList<T> left, final SingleList<T> right) {

		boolean flag = true;
		while (!left.isEmpty() || !right.isEmpty()) {
			if (flag) {
				if (!left.isEmpty()) {
					this.moveFront(left);
				} else {
					this.moveFront(right);
				}
			} else {
				if (!right.isEmpty()) {
					this.moveFront(right);
				} else {
					this.moveFront(left);
				}
			}
			flag = !flag;
		}

	}

	/**
	 * Determines if this SingleList contains key.
	 *
	 * @param key The key value to look for.
	 * @return true if key is in this SingleList, false otherwise.
	 */
	public boolean contains(final T key) {

		return this.count(key) > 0;

	}

	/**
	 * Finds the number of times key appears in list.
	 *
	 * @param key The value to look for.
	 * @return The number of times key appears in this SingleList.
	 */
	public int count(final T key) {
		int n = 0;
		SingleNode<T> current = this.head;

		while (current != null) {
			if (current.getValue().compareTo(key) == 0) {
				n++;
			}
			current = current.getNext();
		}
		return n;
	}

	/**
	 * Finds and returns the value in list that matches key.
	 *
	 * @param key The value to search for.
	 * @return The value that matches key, null otherwise.
	 */
	public T find(final T key) {
		T data = null;
		if (this.count(key)!=0) {
			if (this.length > 0) {
			final SingleNode<T> previous = this.linearSearch(key);

			if (previous == null) {
				// data at front
				data = this.head.getValue();
			} else if (previous.getNext() != null) {
				data = previous.getNext().getValue();
			}
		}
		}
		
		return data;
	}

	/**
	 * Get the nth item in this SingleList.
	 *
	 * @param n The index of the item to return.
	 * @return The nth item in this SingleList.
	 * @throws ArrayIndexOutOfBoundsException if n is not a valid index.
	 */
	public T get(final int n) throws ArrayIndexOutOfBoundsException {
		T data = null;
		if (n < this.length) {
			int i = 0;
			SingleNode<T> node = this.head;
			while (node != null && i < n) {
				node = node.getNext();
				i++;
			}
			data = node.getValue();
		}

		return data;

	}

	/**
	 * Determines whether two lists are identical.
	 *
	 * @param source The list to compare against this SingleList.
	 * @return true if this SingleList contains the same values in the same order as
	 *         source, false otherwise.
	 */
	public boolean identical(final SingleList<T> source) {

		boolean same = true;
		if (this.length == source.length) {
			SingleNode<T> thisNode = this.head;
			SingleNode<T> sourceNode = source.head;
			while (same && thisNode != null) {
				if (thisNode.getValue().compareTo(sourceNode.getValue()) != 0) {
					same = false;
				} else {
					thisNode = thisNode.getNext();
					sourceNode = sourceNode.getNext();
				}
			}
		} else {
			same = false;
		}

		return same;

	}

	/**
	 * Finds the first location of a value by key in this SingleList.
	 *
	 * @param key The value to search for.
	 * @return The index of key in this SingleList, -1 otherwise.
	 */
	public int index(final T key) {

		int i = 0;
		boolean found = false;
		SingleNode<T> node = this.head;
		while (!found && i < this.length) {
			if (node.getValue().compareTo(key) == 0) {
				found = true;
			} else {
				i++;
				node = node.getNext();
			}
		}

		if (!found) {
			i = -1;
		}
		return i;

	}

	/**
	 * Inserts data into this SingleList at index i. If i greater than the length of
	 * this SingleList, append value to the end of this SingleList.
	 *
	 * @param i    The index to insert the new value at.
	 * @param data The new value to insert into this SingleList.
	 */
	public void insert(int i, final T data) {
		// if i is positive loop through normally
		// if i is negative you have to go backwards
		SingleNode<T> node = new SingleNode<T>(data, null);
		// case 1 i is positive

		if (i >= 0) {
			int n = 0;
			// if i is greater than the length append it to the end of the list
			SingleNode<T> curr = this.head;
			if (i >= this.length) {
				while (curr.getNext() != null) {
					curr = curr.getNext();
				}
				curr.setNext(node);
			}
			// if i is 0 then add the node to the front
			else if (i == 0) {
				node.setNext(curr);
				this.head = node;
			}
			// i is not the front or greater than the rear
			else {
				while (n < i - 1) {
					curr = curr.getNext();
					n++;
				}
				// insert the node
				node.setNext(curr.getNext());
				curr.setNext(node);
			}
		} else {
			// if i is negative then we have to go backward...hard
			// if the negative i is less than count add it to the beginning
			if (i <= -1 * this.length) {
				node.setNext(this.head);
				this.head = node;
			} else {
				int a = -1 * this.length;
				SingleNode<T> temp = this.head;
				while (a < i) {
					temp = temp.getNext();
					a++;
				}
				node.setNext(temp.getNext());
				temp.setNext(node);
			}

		}
		this.length++;
		return;

	}

	/**
	 * Inserts data into the front of this SingleList.
	 *
	 * @param data The value to insert into the front of this SingleList.
	 */
	public void insertFront(final T data) {

		SingleNode<T> node = new SingleNode<T>(data, this.head);
		this.head = node;
		this.length++;

	}

	/**
	 * Finds the maximum value in this SingleList.
	 *
	 * @return The maximum value.
	 */
	public T max() {
		T max = null;
		if (this.length > 0) {
			max = this.head.getValue();
			SingleNode<T> curr = this.head;
			while (curr.getNext() != null) {
				if (curr.getValue().compareTo(max) > 0) {
					max = curr.getValue();
				}
				curr = curr.getNext();
			}
		}

		return max;
	}

	/**
	 * Finds the minimum value in this SingleList.
	 *
	 * @return The minimum value.
	 */
	public T min() {
		T min = null;
		if (this.length > 0) {
			min = this.head.getValue();
			SingleNode<T> curr = this.head;
			while (curr.getNext() != null) {
				if (curr.getValue().compareTo(min) < 0) {
					min = curr.getValue();
				}
				curr = curr.getNext();
			}
		}
		return min;

	}

	/**
	 * Finds, removes, and returns the value in this SingleList that matches key.
	 *
	 * @param key The value to search for.
	 * @return The value matching key, null otherwise.
	 */
	public T remove(final T key) {

		boolean found = false;
		SingleNode<T> curr = this.head;
		SingleNode<T> prev = null;
		T data = null;
		if (curr != null) {
			if (curr.getValue().compareTo(key) == 0) {
				found = true;
			}
			while (!found && curr.getNext() != null) {
				if (curr.getValue().compareTo(key) == 0) {
					found = true;
				} else {
					prev = curr;
					curr = curr.getNext();
				}
			}
		}
		if (found) {
			if (prev == null) {
				data = this.head.getValue();
				this.head = this.head.getNext();
			} else {
				prev.setNext(curr.getNext());
				curr.setNext(null);
				data = curr.getValue();
			}
			this.length--;
		}
		return data;
	}

	/**
	 * Removes the value at the front of this SingleList.
	 *
	 * @return The value at the front of this SingleList.
	 */
	public T removeFront() {

		SingleNode<T> node = this.head;
		this.head = this.head.getNext();
		node.setNext(null);
		this.length--;
		return node.getValue();

	}

	/**
	 * Reverses the order of the values in this SingleList.
	 */
	public void reverse() {
		SingleNode<T> newHead = null;
		SingleNode<T> temp = null;

		while (this.head != null) {
			temp = this.head.getNext();
			this.head.setNext(newHead);
			newHead = this.head;
			this.head = temp;
		}
		this.head = newHead;
		return;
	}

	/**
	 * Splits the contents of this SingleList into the left and right SingleLists.
	 * Moves nodes only - does not move data or call the high-level methods insert
	 * or remove. this SingleList is empty when done. The first half of this
	 * SingleList is moved to left, and the last half of this SingleList is moved to
	 * right. If the resulting lengths are not the same, left should have one more
	 * item than right.
	 *
	 * @param left  The first SingleList to move nodes to.
	 * @param right The second SingleList to move nodes to.
	 */
	public void split(final SingleList<T> left, final SingleList<T> right) {

		int mid = this.length/2;
		int i=0;
		if(this.length%2!=0) {
			mid++;
		}
		//move the front half to left
		while(i<mid) {
			left.moveFront(this);
			i++;
		}
		while (!this.isEmpty()) {
			right.moveFront(this);
		}
		return;
	}

	/**
	 * Splits the contents of this SingleList into the left and right SingleLists.
	 * Moves nodes only - does not move data or call the high-level methods insert
	 * or remove. this SingleList is empty when done. Nodes are moved alternately
	 * from this SingleList to left and right.
	 *
	 * @param left  The first SingleList to move nodes to.
	 * @param right The second SingleList to move nodes to.
	 */
	public void splitAlternate(final SingleList<T> left, final SingleList<T> right) {

		boolean flag = true;
		while(!this.isEmpty()) {
			if(flag) {
				left.moveFront(this);
			}
			else {
				right.moveFront(this);
			}
			flag = !flag;
		}
		return;

	}

	/**
	 * Creates a union of two other SingleLists into this SingleList. Copies data to
	 * this list. left and right SingleLists are unchanged.
	 *
	 * @param left  The first SingleList to create a union from.
	 * @param right The second SingleList to create a union from.
	 */
	public void union(final SingleList<T> left, final SingleList<T> right) {

		//move elements from left list
		SingleNode<T> curr = left.head;
		while(curr.getNext()!=null) {
			if(!this.contains(curr.getValue())) {
				this.append(curr.getValue());
			}
			curr = curr.getNext();
		}
		//move elements from right list
		curr = right.head;
		while(curr.getNext()!=null) {
			if(!this.contains(curr.getValue())) {
				this.append(curr.getValue());
			}
			curr = curr.getNext();
		}
		return;

	}
}